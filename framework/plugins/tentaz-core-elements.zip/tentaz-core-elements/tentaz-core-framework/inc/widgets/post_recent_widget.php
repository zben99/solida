<?php

// Register and load the widget
function tentaz_wpb_load_widget() {
    register_widget( 'portsolio_widget' );
}
add_action( 'widgets_init', 'tentaz_wpb_load_widget' );
 
// Creating the widget 
class portsolio_widget extends WP_Widget {
 
function __construct() {
parent::__construct(
 
// Base ID of your widget
'portsolio_widget', 
 
// Widget name will appear in UI
__('Tentaz Portfolio Widget', 'tentaz'), 
 
// Widget description
array( 'description' => __( 'Recent portfolio widget with different options', 'tentaz' ), ) 
);
}
 
// Creating widget front-end
 
public function widget( $args, $instance ) {
if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Recent Projects','tentaz' );

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
		if ( ! $number )
			$number = 5;
		$show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;
		
		$show_featured_image = isset( $instance['show_featured_image'] ) ? $instance['show_featured_image'] : false;

		/**
		 * Filters the arguments for the Recent Posts widget.
		 *
		 * @since 3.4.0
		 *
		 * @see WP_Query::get_posts()
		 *
		 * @param array $args An array of arguments used to retrieve the recent posts.
		 */
		$r = new WP_Query( apply_filters( 'widget_posts_args', array(
      'post_type'      => 'portfolios',
			'posts_per_page'      => $number,
			'no_found_rows'       => true,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true
		) ) );?>

        <div class="recent-widget widget"> 
    		<?php
            if ($r->have_posts()) :
            ?>      
            <?php if ( $title )
            {
              echo wp_kses_post($args['before_title'] . $title . $args['after_title']);
            } ?>
        
            <div class="recent-post-widget clearfix">
              <?php while ( $r->have_posts() ) : $r->the_post(); ?>
                <div class="show-featured clearfix">
                    <div class="post-img"> 
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail('solida_portfolio-slider'); ?>
                        </a> 
                    </div>
                    
              </div>
              <?php 
                
                endwhile; 
                wp_reset_postdata();
                ?>
            </div>
        </div>
        <?php
            // Reset the global $the_post as this query will have stomped on it
            wp_reset_postdata();            
            endif;
            ?>
        <?php
            
        }

// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		$instance['number'] = (int) $new_instance['number'];
		$instance['show_date'] = isset( $new_instance['show_date'] ) ? (bool) $new_instance['show_date'] : false;
		$instance['show_featured_image'] = isset( $new_instance['show_featured_image'] ) ? (bool) $new_instance['show_featured_image'] : false;
		return $instance;
}
         
// Widget Backend 
public function form( $instance ) {
		$title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
		$show_date = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;
		$show_featured_image = isset( $instance['show_featured_image'] ) ? (bool) $instance['show_featured_image'] : false;
?>
<p>
  <label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>">
    <?php esc_html_e( 'Title:','tentaz' ); ?>
  </label>
  <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo esc_js($title); ?>" />
</p>
<p>
  <label for="<?php echo esc_attr($this->get_field_id( 'number' )); ?>">
    <?php esc_html_e( 'Number of posts to show:','tentaz' ); ?>
  </label>
  <input class="tiny-text" id="<?php echo esc_attr($this->get_field_id( 'number' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'number' )); ?>" type="number" step="1" min="1" value="<?php echo esc_js($number); ?>" size="3" />
</p>

<?php
	}

} // Class wpb_widget ends here
