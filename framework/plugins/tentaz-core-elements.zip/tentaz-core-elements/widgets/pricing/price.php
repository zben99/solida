<?php
/**
 * Logo widget class
 *
 */
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Control_Media;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Image_Size;

defined( 'ABSPATH' ) || die();

class tentaz_Elementor_pro_price_Widget extends \Elementor\Widget_Base {
    /**
     * Get widget name.
     *
     * Retrieve tentaz widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */

    public function get_name() {
        return 'tentaz-price';
    }

    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */

    public function get_title() {
        return esc_html__( 'Tentaz Pricing', 'tentaz' );
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-gallery-grid';
    }


    public function get_categories() {
        return [ 'tentazcore_category' ];
    }

    public function get_keywords() {
        return [ 'price' ];
    }


    protected function _register_controls() {       

        $this->start_controls_section(
            '_section_logo',
            [
                'label' => esc_html__( 'Service Item', 'tentaz' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'image',
            [
                'label' => esc_html__('Image', 'tentaz'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );  
      

        $repeater->add_control(
            'name',
            [
                'label' => esc_html__('Title', 'tentaz'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('', 'tentaz'),
                'label_block' => true,
                'placeholder' => esc_html__( 'Title', 'tentaz' ),
                'separator'   => 'before',
            ]
        );

        $repeater->add_control(
            'description',
            [
                'label' => esc_html__('Description', 'tentaz'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('', 'tentaz'),
                'label_block' => true,
                'placeholder' => esc_html__( 'Description', 'tentaz' ),
                'separator'   => 'before',
            ]
        );

        $repeater->add_control(
            'price',
            [
                'label' => esc_html__('Price', 'tentaz'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('', 'tentaz'),
                'label_block' => true,
                'placeholder' => esc_html__( '$49', 'tentaz' ),
                'separator'   => 'before',
            ]
        );

        $this->add_control(
            'price_list',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ name }}}',
                'default' => [
                    ['image' => ['url' => Utils::get_placeholder_image_src()]],
                    ['image' => ['url' => Utils::get_placeholder_image_src()]],
                    ['image' => ['url' => Utils::get_placeholder_image_src()]],
                ]
            ]
        );    

        $this->end_controls_section();
        
    }

    protected function render() {

        $settings = $this->get_settings_for_display();  

        if ( empty($settings['price_list'] ) ) {
            return;
        }
        ?>



            <div class="tentaz-pricing">
                <div class="pricing-list">                   
                        
                        <?php
                            foreach ( $settings['price_list'] as $index => $item ) :
                                $image = wp_get_attachment_image_url( $item['image']['id'], $settings['thumbnail_size'] );
                                $image_icon = wp_get_attachment_image_url( $item['image_icon']['id']);
                                
                                
                                $price        = !empty($item['price']) ? $item['price'] : '';
                                $title        = !empty($item['name']) ? $item['name'] : '';
                                $title_tag    = !empty($settings['title_tag']) ? $settings['title_tag'] : 'h3';
                                $description  = !empty($item['description']) ? $item['description'] : '';
                                
                                                           
                                
                                ?>
                                <div class="grid-item">
                                    <div  class="tentaz-price-wrap">
                                        <?php if(!empty($item['image']['url'])) { ?>
                                            <div class="image-wrap">
                                                <img class="tentaz-grid-img" src="<?php echo esc_url( $image ); ?>" title="<?php echo esc_attr( $item['name'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>">
                                            </div>
                                        <?php } ?>

                                        <div class="price-down-wrap">
	                                        <?php if(!empty($item['name'])):?>                                            
		                                        <div class="price-title">                            
		                                            <<?php echo esc_attr($title_tag);?> class="price-title"> <?php echo esc_attr ($title);?></<?php echo esc_attr($title_tag);?>> 
		                                            <?php if(!empty($item['description'])):?>                      
		                                                <div class="price-desc"><?php echo esc_attr ($description);?></div>
		                                            <?php endif;?>                              
		                                        </div>                                            
	                                        <?php endif; ?>
	                                        <?php if(!empty($item['price'])):?>
	                                            <div class="price">                                              
	                                            <?php echo esc_html($price); ?>
	                                            </div>
	                                        <?php endif;?>
                                    	</div>
                                    </div>
                                </div>           
                            <?php endforeach; ?>
                      
                </div>
            </div>
        <?php
    }
}