<?php
/**
 * Logo widget class
 *
 */
use Elementor\Group_Control_Css_Filter;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Control_Media;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;

defined( 'ABSPATH' ) || die();

class tentaz_proteam__Showcase_Widget extends \Elementor\Widget_Base {
    /**
     * Get widget name.
     *
     * Retrieve logo widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */

    public function get_name() {
        return 'tentaz-logo';
    }

    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */

    public function get_title() {
        return esc_html__( 'Tentaz Team', 'back' );
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-gallery-grid';
    }


    public function get_categories() {
        return [ 'backthemecore_category' ];
    }

    public function get_keywords() {
        return [ 'team', 'people', 'employee' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            '_sectionteam_',
            [
                'label' => esc_html__( 'Team Grid', 'back' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'backteam__style',
            [
                'label'   => esc_html__( 'Select Style', 'back' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'style1',
                'options' => [                  
                    'style1' => esc_html__( 'Style 1', 'back'),
                    'style2' => esc_html__( 'Style 2', 'back'),
                ],
            ]
        );


        $repeater = new Repeater();

        $repeater->add_control(
            'image',
            [
                'label' => esc_html__('Team', 'back'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );


        $repeater->add_control(
            'name',
            [
                'label'       => esc_html__( 'Name', 'tentaz' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => 'Name',
                'placeholder' => esc_html__( 'Name', 'tentaz' ),
                'separator'   => 'before',
            ]
        );

        $repeater->add_control(
            'designation',
            [
                'label'       => esc_html__( 'Designation', 'tentaz' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => 'Designation',
                'placeholder' => esc_html__( 'Designation', 'tentaz' ),
                'separator'   => 'before',
            ]
        );

        $repeater->add_control(
            'facebook',
            [
                'label'       => esc_html__( 'Facebook', 'tentaz' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => '',
                'placeholder' => esc_html__( 'Facebook', 'tentaz' ),
                'separator'   => 'before',
            ]
        );
        $repeater->add_control(
            'facebook',
            [
                'label'       => esc_html__( 'Facebook', 'tentaz' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => '',
                'placeholder' => esc_html__( 'Facebook', 'tentaz' ),
                'separator'   => 'before',
            ]
        );
        $repeater->add_control(
            'twitter',
            [
                'label'       => esc_html__( 'Twitter', 'tentaz' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => '',
                'placeholder' => esc_html__( 'Twitter', 'tentaz' ),
                'separator'   => 'before',
            ]
        );

        $repeater->add_control(
            'instagram',
            [
                'label'       => esc_html__( 'Instagram', 'tentaz' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => '',
                'placeholder' => esc_html__( 'Instagram', 'tentaz' ),
                'separator'   => 'before',
            ]
        );

        $repeater->add_control(
            'linkedin',
            [
                'label'       => esc_html__( 'Linkedin', 'tentaz' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => '',
                'placeholder' => esc_html__( 'Linkedin', 'tentaz' ),
                'separator'   => 'before',
            ]
        );


        $repeater->add_control(
            'youtube',
            [
                'label'       => esc_html__( 'Youtube', 'tentaz' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => '',
                'placeholder' => esc_html__( 'Youtube', 'tentaz' ),
                'separator'   => 'before',
            ]
        );

        $this->add_control(
            'team_list',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ name }}}',
                'default' => [
                    ['image' => ['url' => Utils::get_placeholder_image_src()]],
                    ['image' => ['url' => Utils::get_placeholder_image_src()]],
                    ['image' => ['url' => Utils::get_placeholder_image_src()]],
                    ['image' => ['url' => Utils::get_placeholder_image_src()]],
                    ['image' => ['url' => Utils::get_placeholder_image_src()]],
                    ['image' => ['url' => Utils::get_placeholder_image_src()]],
                    ['image' => ['url' => Utils::get_placeholder_image_src()]],
                    ['image' => ['url' => Utils::get_placeholder_image_src()]],
                ]
            ]
        );        

        $this->end_controls_section();

        $this->start_controls_section(
            '_images_settings',
            [
                'label' => esc_html__( 'Image Settings', 'back' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_responsive_control(
            'image_width',
            [
                'label' => esc_html__( 'Image Height', 'back' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 400,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .logo-img img' => 'max-height: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_settings',
            [
                'label' => esc_html__( 'Settings', 'back' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_responsive_control(
            'align',
            [
                'label' => esc_html__( 'Alignment', 'back' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'back' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'back' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'back' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__( 'Justify', 'back' ),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .back-grid-figure' => 'text-align: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'large',
                'separator' => 'before',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->add_control(
            'layout',
            [
                'label' => esc_html__( 'Select Style', 'back' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'grid' => esc_html__( 'Grid', 'back' ),
                    'slider' => esc_html__( 'Slider', 'back' ),
                   
                ],
                'default' => 'slider',            
            ]
        );


        $this->add_control(
            'columns',
            [
                'label' => esc_html__( 'Columns', 'back' ),
                'type' => Controls_Manager::SELECT,
                'default' => 4,
                'options' => [
                    6 => esc_html__( '2 Columns', 'back' ),
                    4 => esc_html__( '3 Columns', 'back' ),
                    3 => esc_html__( '4 Columns', 'back' ),                  
                    2 => esc_html__( '6 Columns', 'back' ),
                ],                           
            ]
        );

        $this->add_control(
            'columns-gap',
            [
                'label' => esc_html__( 'Columns Gap', 'back' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => esc_html__( 'Default', 'back' ),
                    'no-padding' => esc_html__( 'No Gap', 'back' ),                   
                ],                           
            ]
        );

        $this->end_controls_section();


   
        $this->start_controls_section(
            '_section_style_grid',
            [
                'label' => esc_html__( 'Item', 'back' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'padding',
            [
                'label' => esc_html__( 'Padding', 'back' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .back-grid-figure' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'margin',
            [
                'label' => esc_html__( 'Margin', 'back' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .back-grid-figure' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        

        $this->start_controls_tabs(
            '_tabs_image_effects',
            [
                'separator' => 'before'
            ]
        );

        $this->start_controls_tab(
            '_tab_image_effects_normal',
            [
                'label' => esc_html__( 'Normal', 'back' ),
            ]
        );

        $this->add_control(
            'image_opacity',
            [
                'label' => esc_html__( 'Opacity', 'back' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 1,
                        'min' => 0.10,
                        'step' => 0.01,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .back-grid-figure .back-grid-img' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'image_blur',
            [
                'label' => esc_html__( 'Blur', 'back' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 100,
                        'min' => 0,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .back-grid-figure .back-grid-img' => 'filter: blur({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Css_Filter::get_type(),
            [
                'name' => 'image_css_filters',
                'selector' => '{{WRAPPER}} .back-grid-figure .back-grid-img',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'hover',
            [
                'label' => esc_html__( 'Hover', 'back' ),
            ]
        );

        $this->add_control(
            'image_opacity_hover',
            [
                'label' => esc_html__( 'Opacity', 'back' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 1,
                        'min' => 0.10,
                        'step' => 0.01,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .back-grid-figure:hover .back-grid-img' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'image_blur_hover',
            [
                'label' => esc_html__( 'Blur', 'back' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 100,
                        'min' => 0,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .back-grid-figure:hover .back-grid-img' => 'filter: blur({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Css_Filter::get_type(),
            [
                'name' => 'image_css_filte_hover',
                'selector' => '{{WRAPPER}} .back-grid-figure:hover .back-grid-img',
            ]
        );

        $this->add_control(
            'image_scale',
            [
                'label' => esc_html__( 'Zoom', 'back' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .back-grid-figure:hover .back-grid-img' => 'transform: scale({{image_scale.SIZE}})',
                ],
            ]
        );

        $this->add_control(
            'image_bg_hover_transition',
            [
                'label' => esc_html__( 'Transition Duration', 'back' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .back-grid-figure:hover .back-grid-img' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
    }

    protected function render() {

        $settings = $this->get_settings_for_display();   

        if ( empty($settings['team_list'] ) ) {
            return;
        }
        ?>
        <div class="tentaz-team-grid">
            <div class="row">
            <?php
                foreach ( $settings['team_list'] as $index => $item ) :
                    $image = wp_get_attachment_image_url( $item['image']['id'], $settings['thumbnail_size'] );
                    if ( ! $image ) {
                        $image = Utils::get_placeholder_image_src();
                    }
                    $gap = $settings['columns-gap'] == 'no-padding' ? 'no-padding' : '';
                    $facebook         = !empty($item['facebook']['url']) ? $item['facebook']['url'] : '';
                    $twitter         = !empty($item['twitter']['url']) ? $item['twitter']['url'] : '';
                    $youtube         = !empty($item['youtube']['url']) ? $item['youtube']['url'] : '';
                    $instagram         = !empty($item['instagram']['url']) ? $item['instagram']['url'] : '';
                    $linkedin         = !empty($item['linkedin']['url']) ? $item['linkedin']['url'] : '';
                    
                    $name = !empty($item['name']) ? $item['name'] : '';
                    $designation = !empty($item['designation']) ? $item['designation'] : '';
                    ?>
                    <div class="col-lg-<?php echo esc_attr($settings['columns']);?> <?php echo esc_attr( $gap );?> col-sm-6 col-md-6">
                        <div  class="team-grid-figure">
                            <div class="team-img">                                
                                <img src="<?php echo esc_url( $image ); ?>" alt="image">
                                <?php if(!empty($item['facebook']) || !empty($item['twitter']) || !empty($item['youtube']) || !empty($item['instagram']) || !empty($item['linkedin'])){ ?> 
                                <ul class="tentaz__team__social"> 
                                    <?php if(!empty($item['facebook'])) : ?>                                   
                                    <li><a href="<?php echo esc_url($facebook);?>" target="_blank"><i class="ri-facebook-fill"></i></a></li>
                                    <?php endif; ?>
                                    <?php if(!empty($item['twitter'])) : ?>
                                    <li><a href="<?php echo esc_url($twitter);?>" target="_blank"><i class="ri-twitter-fill"></i></a></li>
                                    <?php endif; ?>
                                    <?php if(!empty($item['youtube'])) : ?>
                                    <li><a href="<?php echo esc_url($youtube);?>" target="_blank"><i class="ri-youtube-fill"></i></a></li>
                                    <?php endif; ?>
                                    <?php if(!empty($item['instagram'])) : ?>
                                    <li><a href="<?php echo esc_url($instagram);?>" target="_blank"><i class="ri-instagram-line"></i></a></li>
                                    <?php endif; ?>
                                    <?php if(!empty($item['linkedin'])) : ?>
                                    <li><a href="<?php echo esc_url($linkedin);?>" target="_blank"><i class="ri-linkedin-fill"></i></a></li>
                                    <?php endif; ?>
                                </ul>
                            <?php } ?>
                            </div> 
                            <?php if(!empty($item['name']) || !empty($item['designation'])){ ?>  
                                <ul class="team_desina">
                                    <?php if(!empty($item['designation'])) : ?>
                                        <li class="deg"><?php echo esc_html($designation); ?></li>
                                    <?php endif; ?>
                                    <?php if(!empty($item['name'])) : ?>
                                        <li class="name"> <?php echo esc_html($name); ?> </li>
                                    <?php endif; ?>                                    
                                </ul>
                            <?php } ?>                             
                        </div>
                    </div>                   
                <?php endforeach; ?>
            </div>
        </div>
        <?php 
    }
}