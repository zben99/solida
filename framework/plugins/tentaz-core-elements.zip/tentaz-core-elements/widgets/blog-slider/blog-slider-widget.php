<?php
/**
 * Elementor Blog Slider Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */

use Elementor\Controls_Manager;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Utils;

defined( 'ABSPATH' ) || die();

class tentaz_Blog_Slider_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve rsgallery widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'tentazblog-slider';
    }       

    /**
     * Get widget title.
     *
     * Retrieve rsgallery widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Tentaz Blog Slider', 'tentaz' );
    }

    /**
     * Get widget icon.
     *
     * Retrieve rsgallery widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'glyph-icon flaticon-slider-1';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the rsgallery widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tentazcore_category' ];
    }

    /**
     * Register rsgallery widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {       

        $category_dropdown[0] = 'Select Category';
        
        $terms  = get_terms( array( 'taxonomy' => "category", 'fields' => 'id=>name' ) );       
        foreach ( $terms as $id => $name ) {
            $category_dropdown[$id] = $name;
        } 


        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'tentaz' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

       
        $this->add_control(
            'category',
            [
                'label'   => esc_html__( 'Category', 'tentaz' ),
                'type'    => Controls_Manager::SELECT2, 
                'default' => 0,         
                'options' => [      
                        
                ]+ $category_dropdown,
                'multiple' => true, 
                'separator' => 'before',        
            ]

        );
        


        $this->add_control(
            'per_page',
            [
                'label' => esc_html__( 'Blog Show Per Page', 'tentaz' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( '6', 'tentaz' ),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'blog_content_postion_style',
            [
                'label' => esc_html__( 'Blog Style', 'tentaz' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => esc_html__( 'Default', 'tentaz' ),
                    'style1' => esc_html__( 'Style 1', 'tentaz' ),
                    'style2' => esc_html__( 'Style 2', 'tentaz' ),
                ],                
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'blog_title_word_show',
            [
                'label' => esc_html__( 'Title Word Limit', 'tentaz' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => esc_html__( '10', 'tentaz' ),
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'large',
                'separator' => 'before',
                'exclude' => [
                    'custom'
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'align',
            [
                'label' => esc_html__( 'Alignment', 'tentaz' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'tentaz' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'tentaz' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'tentaz' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__( 'Justify', 'tentaz' ),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .tentaz-blog-grid .blog-down-wrap' => 'text-align: {{VALUE}}'
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'btn_text',
            [
                'label'       => esc_html__( 'Button Text', 'back' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => 'Read More',
                'placeholder' => esc_html__( 'Button Text', 'back' ),
                'separator'   => 'before',
            ]
        );

        $this->end_controls_section();

        //start slider settings
        $this->start_controls_section(
            'section_slider_settings',
            [
                'label' => esc_html__( 'Slider Settings', 'tentaz' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'col_lg',
            [
                'label'   => esc_html__( 'Desktops > 1199px', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 3,
                'options' => [
                    '1' => esc_html__( '1 Column', 'tentaz' ), 
                    '2' => esc_html__( '2 Column', 'tentaz' ),
                    '3' => esc_html__( '3 Column', 'tentaz' ),
                    '4' => esc_html__( '4 Column', 'tentaz' ),
                    '6' => esc_html__( '6 Column', 'tentaz' ),                 
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'col_md',
            [
                'label'   => esc_html__( 'Desktops > 991px', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 3,         
                'options' => [
                    '1' => esc_html__( '1 Column', 'tentaz' ), 
                    '2' => esc_html__( '2 Column', 'tentaz' ),
                    '3' => esc_html__( '3 Column', 'tentaz' ),
                    '4' => esc_html__( '4 Column', 'tentaz' ),
                    '6' => esc_html__( '6 Column', 'tentaz' ),                     
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'col_sm',
            [
                'label'   => esc_html__( 'Tablets > 767px', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 2,         
                'options' => [
                    '1' => esc_html__( '1 Column', 'tentaz' ), 
                    '2' => esc_html__( '2 Column', 'tentaz' ),
                    '3' => esc_html__( '3 Column', 'tentaz' ),
                    '4' => esc_html__( '4 Column', 'tentaz' ),
                    '6' => esc_html__( '6 Column', 'tentaz' ),                 
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'col_xs',
            [
                'label'   => esc_html__( 'Tablets < 768px', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 1,         
                'options' => [
                    '1' => esc_html__( '1 Column', 'tentaz' ), 
                    '2' => esc_html__( '2 Column', 'tentaz' ),
                    '3' => esc_html__( '3 Column', 'tentaz' ),
                    '4' => esc_html__( '4 Column', 'tentaz' ),
                    '6' => esc_html__( '6 Column', 'tentaz' ),                 
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slides_ToScroll',
            [
                'label'   => esc_html__( 'Slide To Scroll', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 2,         
                'options' => [
                    '1' => esc_html__( '1 Item', 'tentaz' ),
                    '2' => esc_html__( '2 Item', 'tentaz' ),
                    '3' => esc_html__( '3 Item', 'tentaz' ),
                    '4' => esc_html__( '4 Item', 'tentaz' ),                   
                ],
                'separator' => 'before',
                            
            ]
            
        );

        

        $this->add_control(
            'slider_dots',
            [
                'label'   => esc_html__( 'Navigation Dots', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 'false',
                'options' => [
                    'true' => esc_html__( 'Enable', 'tentaz' ),
                    'false' => esc_html__( 'Disable', 'tentaz' ),              
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_nav',
            [
                'label'   => esc_html__( 'Navigation Nav', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 'false',           
                'options' => [
                    'true' => esc_html__( 'Enable', 'tentaz' ),
                    'false' => esc_html__( 'Disable', 'tentaz' ),              
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_autoplay',
            [
                'label'   => esc_html__( 'Autoplay', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 'false',           
                'options' => [
                    'true' => esc_html__( 'Enable', 'tentaz' ),
                    'false' => esc_html__( 'Disable', 'tentaz' ),              
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_autoplay_speed',
            [
                'label'   => esc_html__( 'Autoplay Slide Speed', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 3000,          
                'options' => [
                    '1000' => esc_html__( '1 Seconds', 'tentaz' ),
                    '2000' => esc_html__( '2 Seconds', 'tentaz' ), 
                    '3000' => esc_html__( '3 Seconds', 'tentaz' ), 
                    '4000' => esc_html__( '4 Seconds', 'tentaz' ), 
                    '5000' => esc_html__( '5 Seconds', 'tentaz' ), 
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_stop_on_hover',
            [
                'label'   => esc_html__( 'Stop on Hover', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',               
                'options' => [
                    'true' => esc_html__( 'Enable', 'tentaz' ),
                    'false' => esc_html__( 'Disable', 'tentaz' ),              
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_interval',
            [
                'label'   => esc_html__( 'Autoplay Interval', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 3000,          
                'options' => [
                    '5000' => esc_html__( '5 Seconds', 'tentaz' ), 
                    '4000' => esc_html__( '4 Seconds', 'tentaz' ), 
                    '3000' => esc_html__( '3 Seconds', 'tentaz' ), 
                    '2000' => esc_html__( '2 Seconds', 'tentaz' ), 
                    '1000' => esc_html__( '1 Seconds', 'tentaz' ),     
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_loop',
            [
                'label'   => esc_html__( 'Loop', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',
                'options' => [
                    'true' => esc_html__( 'Enable', 'tentaz' ),
                    'false' => esc_html__( 'Disable', 'tentaz' ),
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_centerMode',
            [
                'label'   => esc_html__( 'Center Mode', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',
                'options' => [
                    'true' => esc_html__( 'Enable', 'tentaz' ),
                    'false' => esc_html__( 'Disable', 'tentaz' ),
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->end_controls_section(); //end slider settings


        $this->start_controls_section(
            'section_slider_style',
            [
                'label' => esc_html__( 'Blog Style', 'tentaz' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_control(
            'blog_meta_color',
            [
                'label' => esc_html__( 'Meta Color', 'tentaz' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tentaz-blog-grid .blog-inner-wrap .blog-down-wrap .blog-meta' => 'color: {{VALUE}};',

                ],                
            ]
        );

        $this->add_control(
            'blog_meta_icon_color',
            [
                'label' => esc_html__( 'Meta Icon Color', 'tentaz' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tentaz-blog-grid .blog-inner-wrap .blog-down-wrap .blog-meta .date i' => 'color: {{VALUE}};',

                ],                
            ]
        );
      
        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Title Color', 'tentaz' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tentaz-blog-grid .blog-inner-wrap .blog-down-wrap .post-title a' => 'color: {{VALUE}};',

                ],                
            ]
        );

        $this->add_control(
            'title_color_hover',
            [
                'label' => esc_html__( 'Title Color(Hover)', 'tentaz' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tentaz-blog-grid .blog-inner-wrap .blog-down-wrap .post-title a:hover' => 'color: {{VALUE}};',
                ],                
            ]

            
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => esc_html__( 'Title Typography', 'tentaz' ),
                'selector' => 
                    '{{WRAPPER}} .tentaz-blog-grid .blog-inner-wrap .blog-down-wrap .post-title',
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__( 'Content Color', 'tentaz' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tentaz-blog-grid .tentaz-excerpt' => 'color: {{VALUE}};',

                ],                
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render rsgallery widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $settings = $this->get_settings_for_display(); 

        $slidesToShow    = !empty($settings['col_lg']) ? $settings['col_lg'] : 3;
        $autoplaySpeed   = $settings['slider_autoplay_speed'];
        $interval        = $settings['slider_interval'];
        $slidesToScroll  = $settings['slides_ToScroll'];
        $slider_autoplay = $settings['slider_autoplay'] === 'true' ? 'true' : 'false';
        $pauseOnHover    = $settings['slider_stop_on_hover'] === 'true' ? 'true' : 'false';
        $sliderDots      = $settings['slider_dots'] == 'true' ? 'true' : 'false';
        $sliderNav       = $settings['slider_nav'] == 'true' ? 'true' : 'false';        
        $infinite        = $settings['slider_loop'] === 'true' ? 'true' : 'false';
        $centerMode      = $settings['slider_centerMode'] === 'true' ? 'true' : 'false';
        $col_lg          = $settings['col_lg'];
        $col_md          = $settings['col_md'];
        $col_sm          = $settings['col_sm'];
        $col_xs          = $settings['col_xs'];
       
        $unique = rand(100,31120);

        $slider_conf = compact('slidesToShow', 'autoplaySpeed', 'interval', 'slidesToScroll', 'slider_autoplay','pauseOnHover', 'sliderDots', 'sliderNav', 'infinite', 'centerMode', 'col_lg', 'col_md', 'col_sm', 'col_xs');
        ?>
            <div class="tentaz-unique-slider tentaz-blog-grid <?php echo esc_html($settings['blog_content_postion_style']);?>">
                <div id="tentaz-slick-slider-<?php echo esc_attr($unique); ?>" class="tentaz-addon-slider">
                    <?php 
                        $cat = $settings['category'];
                        if(empty($cat)){
                            $tentaz_best_wp = new wp_Query(array(
                                'post_type'      => 'post',
                                'posts_per_page' => $settings['per_page'],              
                            ));   
                        }   
                        else{
                            $tentaz_best_wp = new wp_Query(array(
                                'post_type'      => 'post',
                                'posts_per_page' => $settings['per_page'],
                                'tax_query'      => array(
                                    array(
                                        'taxonomy' => 'category',
                                        'field'    => 'term_id', 
                                        'terms'    => $cat 
                                    ),
                                )
                            ));   
                        }
                      
                        while($tentaz_best_wp->have_posts()): $tentaz_best_wp->the_post(); 

                        $full_date      = get_the_date();
                        $blog_date1      = get_the_date('d');    
                        $blog_date      = get_the_date('M');    
                        $post_admin     = get_the_author();

                        if(!empty($settings['blog_title_word_show'])){
                            $limit = $settings['blog_title_word_show'];
                        }
                        else{
                            $limit = 200;
                        }
                        ?>   
                        <?php if( $settings['blog_content_postion_style'] == 'style1' ){ ?>                    
                        <div class="blog-item <?php echo esc_html($settings['blog_content_postion_style']);?>">
                            <div class="blog-inner-wrap">
                                <div class="image-wrap">
                                    <a href="<?php the_permalink();?>">
                                        <?php the_post_thumbnail($settings['thumbnail_size']); ?>
                                    </a> 
                                    
                                </div>
                                <div class="blog-down-wrap">
                                        <div class="date_full_blog">
                                            <em><?php echo esc_html($blog_date1); ?></em>
                                            <?php echo esc_html($blog_date); ?>
                                        </div>
                                        <div class="category_listd">                                             
                                            <span><i class="ri-user-3-line"></i> <?php echo esc_html($post_admin); ?></span> 
                                        </div>
                                    
                                    <h3 class="post-title"><a href="<?php the_permalink(); ?>"> <?php echo wp_trim_words( get_the_title(), $limit, '' ); ?> </a></h3>
                                    <?php if(!empty($settings['btn_text'])){ ?>
                                     <a href="<?php the_permalink(); ?>" class="tn-blog-btn"><?php echo esc_html($settings['btn_text']);?> <i class="ri-arrow-right-line"></i></a> 
                                 <?php } ?>
                                </div>   
                            </div>
                        </div>
                        <?php } else { ?>
                        <div class="blog-item <?php echo esc_html($settings['blog_content_postion_style']);?>">
                            <div class="blog-inner-wrap">
                                <div class="image-wrap">
                                    <a href="<?php the_permalink();?>">
                                        <?php the_post_thumbnail($settings['thumbnail_size']); ?>
                                    </a> 
                                </div>
                                <div class="blog-down-wrap">
                                    <?php the_category( ); ?> 
                                    <div class="blog-down-wrap-inner">      
                                            <div class="category_list">
                                                <strong> <?php echo esc_html($post_admin); ?> </strong> 
                                                <em><?php echo esc_html( '-', 'coran' ); ?></em> 
                                                <span> <?php echo esc_html($full_date); ?> </span>  
                                            </div>
                                        
                                        <h3 class="post-title"><a href="<?php the_permalink(); ?>"> <?php echo wp_trim_words( get_the_title(), $limit, '' ); ?> </a></h3>
                                       <?php if(!empty($settings['btn_text'])){ ?>
                                         <a href="<?php the_permalink(); ?>" class="tn-blog-btn"><?php echo esc_html($settings['btn_text']);?> <i class="ri-arrow-right-line"></i></a> 
                                     <?php } ?>
                                    </div>   
                                </div>   
                            </div>
                        </div>
                        <?php }
         
                        endwhile;
                        wp_reset_query();  ?>
                
                </div>
                <div class="tentaz-slider-conf wpsisac-hide" data-conf="<?php echo htmlspecialchars(json_encode($slider_conf)); ?>"></div>
            </div>
            <script type="text/javascript"> 
            jQuery(document).ready(function(){
            jQuery( '.tentaz-addon-slider' ).each(function( index ) {        
            var slider_id       = jQuery(this).attr('id'); 
            var slider_conf     = jQuery.parseJSON( jQuery(this).closest('.tentaz-unique-slider').find('.tentaz-slider-conf').attr('data-conf'));
           
            if( typeof(slider_id) != 'undefined' && slider_id != '' ) {
            jQuery('#'+slider_id).not('.slick-initialized').slick({
            slidesToShow    : parseInt(slider_conf.col_lg),
            centerMode      : (slider_conf.centerMode)  == "true" ? true : false,
            dots            : (slider_conf.sliderDots)  == "true" ? true : false,
            arrows          : (slider_conf.sliderNav) == "true" ? true : false,
            autoplay        : (slider_conf.slider_autoplay) == "true" ? true : false,
            slidesToScroll  : parseInt(slider_conf.slidesToScroll),
            centerPadding   : '0px',
            autoplaySpeed   : parseInt(slider_conf.autoplaySpeed),
            pauseOnHover    : (slider_conf.pauseOnHover) == "true" ? true : false,
            loop : false,

            responsive: [{
                breakpoint: 1200,
                settings: {
                    slidesToShow: parseInt(slider_conf.col_md),
                }
            }, 
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: parseInt(slider_conf.col_sm),
                }
            }, 
            {
                breakpoint: 768,
                settings: {
                    arrows: false,
                    slidesToShow: parseInt(slider_conf.col_xs),
                }
            }, ]
            });
        }
       
        });
    });
    </script>
        <?php
    }
}