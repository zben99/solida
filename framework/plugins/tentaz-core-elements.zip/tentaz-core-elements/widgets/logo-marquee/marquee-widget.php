<?php
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Control_Media;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;

defined("ABSPATH") || die();

class tentaz_marquee__Slider_Widget extends \Elementor\Widget_Base
{
    /**
     * Get widget name.
     *
     * widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */

    public function get_name()
    {
        return "tentaz-mar-slider";
    }

    /**
     * Get widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */

    public function get_title()
    {
        return esc_html__("Tentaz Marquee Slider", "tentaz");
    }

    /**
     * Get widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return "eicon-gallery-grid";
    }

    public function get_categories()
    {
        return ["tentaz_category"];
    }

    public function get_keywords()
    {
        return ["slider", "marquee", "marquee slider"];
    }

    protected function register_controls()
    {
        $this->start_controls_section("_section_marquee", [
            "label" => esc_html__("Marquee Text", "tentaz"),
            "tab" => Controls_Manager::TAB_CONTENT,
        ]);
        
        $repeater = new Repeater();

        $repeater->add_control("marquee_text", [
            "label" => esc_html__("Marquee Text", "tentaz"),
            "type" => Controls_Manager::TEXTAREA,
            "label_block" => true,
            "placeholder" => esc_html__("Marquee Text", "tentaz"),
            "separator" => "before",
        ]);

        $repeater->add_control("image", [
            "label" => esc_html__("Image", "tentaz"),
            "type" => Controls_Manager::MEDIA,
            "default" => [
                "url" => Utils::get_placeholder_image_src(),
            ],
        ]);

        $this->add_control("marquee_list", [
            "show_label" => false,
            "type" => Controls_Manager::REPEATER,
            "fields" => $repeater->get_controls(),
            "title_field" => "{{{ name }}}",
            "default" => [
                ["image" => ["url" => Utils::get_placeholder_image_src()]],
                ["image" => ["url" => Utils::get_placeholder_image_src()]],
                ["image" => ["url" => Utils::get_placeholder_image_src()]],
                ["image" => ["url" => Utils::get_placeholder_image_src()]],
            ],
        ]);


        $this->add_control("tentaz_slide_speed", [
            "label" => esc_html__("Slider Speed", "tentaz"),
            "type" => Controls_Manager::TEXT,
            "label_block" => true,
            "default" => 6000,
            "placeholder" => esc_html__("6000", "tentaz"),
        ]);


        $this->add_group_control(Group_Control_Image_Size::get_type(), [
            "name" => "thumbnail",
            "default" => "large",
            "separator" => "before",
            "exclude" => ["custom"],
            "separator" => "before",
        ]);

        $this->add_control("marquee_direction", [
            "label" => esc_html__("Marquee Direction", "tentaz"),
            "type" => Controls_Manager::SELECT,
            "default" => "1",
            "options" => [
                "1" => esc_html__("Direction Left", "tentaz"),
                "2" => esc_html__("Direction Right", "tentaz"),
            ],
        ]);

        $this->add_control("color", [
            "label" => esc_html__("Color", "prelements"),
            "type" => Controls_Manager::COLOR,
            "selectors" => [
                "{{WRAPPER}} .tentaz-marquee_wrapper .item-inner .tentaz-mar-text" =>
                    "color: {{VALUE}};",
            ],
        ]);

        $this->add_group_control(Group_Control_Typography::get_type(), [
            "name" => "text_typography",
            "label" => esc_html__("Typography", "prelements"),
            "selector" =>
                "{{WRAPPER}} .tentaz-marquee_wrapper .item-inner .tentaz-mar-text",
        ]);

        $this->add_responsive_control("padding", [
            "label" => esc_html__("Padding", "prelements"),
            "type" => Controls_Manager::DIMENSIONS,
            "size_units" => ["px", "em", "%"],
            "selectors" => [
                "{{WRAPPER}} .tentaz-marquee_wrapper .item-inner" =>
                    "padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};",
            ],
        ]);

        $this->add_responsive_control("image_width", [
            "label" => esc_html__("Width", "tentaz"),
            "type" => Controls_Manager::SLIDER,
            "size_units" => ["px", "%"],
            "range" => [
                "%" => [
                    "min" => 0,
                    "max" => 100,
                ],
                "px" => [
                    "min" => -20,
                    "max" => 800,
                ],
            ],
            "selectors" => [
                "{{WRAPPER}} .tentaz-marquee_wrapper .item-inner .tentaz-mar-image img" =>
                    "width: {{SIZE}}{{UNIT}}",
            ],
        ]);

        $this->add_control("hr", [
            "type" => \Elementor\Controls_Manager::DIVIDER,
        ]);

        $this->add_control("text_stroke_style_heading", [
            "label" => esc_html__("Text Stroke Style", "tentaz"),
            "type" => \Elementor\Controls_Manager::HEADING,
        ]);

        $this->add_control("ten-text_stroke_enable_disable", [
            "label" => esc_html__("Text Stroke", "tentaz"),
            "type" => Controls_Manager::SELECT,
            "default" => "disable",
            "options" => [
                "enable" => esc_html__("Enable", "tentaz"),
                "disable" => esc_html__("Disable", "tentaz"),
            ],
        ]);
        $this->add_control("text_stroke_color", [
            "label" => esc_html__("Stroke Color", "tentaz"),
            "type" => Controls_Manager::COLOR,
            "selectors" => [
                "{{WRAPPER}} .tentaz-marquee_wrapper.text-border-enable .tentaz-mar-text" =>
                    "-webkit-text-stroke-color: {{VALUE}}; text-stroke-color: {{VALUE}};",
            ],
            "condition" => [
                "ten-text_stroke_enable_disable" => "enable",
            ],
        ]);
        $this->add_responsive_control("text_stroke_width", [
            "label" => esc_html__("Stroke Width", "tentaz"),
            "type" => Controls_Manager::SLIDER,
            "size_units" => ["%", "px"],
            "show_label" => true,
            "selectors" => [
                "{{WRAPPER}} .tentaz-marquee_wrapper.text-border-enable .tentaz-mar-text" =>
                    "-webkit-text-stroke-width: {{SIZE}}{{UNIT}}; text-stroke-width: {{SIZE}}{{UNIT}};",
            ],
            "condition" => [
                "ten-text_stroke_enable_disable" => "enable",
            ],
        ]);
        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $unique = rand(2012, 35120);

        if (empty($settings["marquee_list"])) {
            return;
        }
        /*----------marquee slider style-------
 -----------------------------*/
        ?>

 <?php if ("2" === $settings["marquee_direction"]) { ?>

<div class="tentaz-marquee_wrapper text-border-<?php echo esc_attr( $settings["ten-text_stroke_enable_disable"]); ?>">
<div class="tentaz-mar-slider_<?php echo $unique; ?>" dir="rtl" data-speed="<?php echo esc_attr($settings["tentaz_slide_speed"]); ?>">
    <?php foreach ($settings["marquee_list"] as $index => $item):

    $image = wp_get_attachment_image_url(
        $item["image"]["id"],
        $settings["thumbnail_size"]);
    $marquee_text = !empty($item["marquee_text"]) ? $item["marquee_text"] : "";
    ?>
 <div class="item">
 <div class="item-inner">
 <?php if (!empty($item["marquee_text"])) { ?>
 <div class="tentaz-mar-text"> <?php echo esc_html($marquee_text); ?> </div>
 <?php } ?>
 <?php if (!empty($item["image"]["url"])) { ?>
 <div class="tentaz-mar-image"><img src="<?php echo esc_url(
     $image
 ); ?>" alt="marquee image"></div>
 <?php } ?>
 </div>
 </div>
 <?php
 endforeach; ?>
 </div>
 </div>

    <script type="text/javascript"> 
        jQuery(document).ready(function(){
        var speedValue = jQuery(".tentaz-mar-slider_<?php echo $unique; ?>").data("speed");
        jQuery(".tentaz-mar-slider_<?php echo $unique; ?>").slick({
             arrows: false,
             infinite: true,
             autoplay: true,
             centerMode: true,
             dots: false,
             variableWidth: true,
             slidesToScroll: 1,
             speed: speedValue,
             autoplay: true,
             autoplaySpeed: 0,
             cssEase: "linear",
             pauseOnHover: false,
             pauseOnFocus: false,
             draggable: true,
             rtl: true,
             responsive: [
             {
             breakpoint: 1200,
             settings: {
             slidesToShow: 5
             }
             },
             {
             breakpoint: 767,
             settings: {
             slidesToShow: 3,
             speed: speedValue,
             dots: false
             }
             }
             ]
             });
        });
    </script>
 <?php } else { ?>

 <div class="tentaz-marquee_wrapper text-border-<?php echo esc_attr($settings["ten-text_stroke_enable_disable"]); ?>">
 <div class="tentaz-mar-slider_<?php echo $unique; ?>" data-speed="<?php echo esc_attr($settings["tentaz_slide_speed"]); ?>">
 <?php foreach ($settings["marquee_list"] as $index => $item):

     $image = wp_get_attachment_image_url(
         $item["image"]["id"],
         $settings["thumbnail_size"]
     );
     $marquee_text = !empty($item["marquee_text"]) ? $item["marquee_text"] : "";
     ?>
 <div class="item">
 <div class="item-inner">
 <?php if (!empty($item["marquee_text"])) { ?>
  <div class="tentaz-mar-text"> <?php echo esc_html($marquee_text); ?> </div>
  <?php } ?>
  <?php if (!empty($item["image"]["url"])) { ?>
     <div class="tentaz-mar-image"><img src="<?php echo esc_url($image); ?>" alt="marquee image"></div>
 <?php } ?>
 </div>
 </div>
 <?php
 endforeach; ?>
 </div>
 </div>

 <script type="text/javascript"> 
 jQuery(document).ready(function(){
 var speedValue = jQuery(".tentaz-mar-slider_<?php echo $unique; ?>").data("speed");
 jQuery(".tentaz-mar-slider_<?php echo $unique; ?>").slick({
 arrows: false,
 infinite: true,
 autoplay: true,
 centerMode: true,
 dots: false,
 variableWidth: true,
 slidesToScroll: 1,
 speed: speedValue,
 autoplaySpeed: 0,
 cssEase: "linear",
 pauseOnHover: false,
 pauseOnFocus: false,
 draggable: true,
 rtl: false,
 responsive: [
 {
 breakpoint: 1200,
 settings: {
 slidesToShow: 5
 }
 },
 {
 breakpoint: 767,
 settings: {
 slidesToShow: 3,
 speed: speedValue,
 dots: false
 }
 }
 ]
 });
 });
 </script>

 <?php } ?>
 <?php
    }
}
