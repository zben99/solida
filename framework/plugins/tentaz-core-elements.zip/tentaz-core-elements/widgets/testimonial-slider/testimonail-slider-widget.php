<?php
/**
 * Elementor testimonial Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */

use Elementor\Controls_Manager;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Utils;

defined( 'ABSPATH' ) || die();

class tentaz_Testimonial_Slider_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve testimonial widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'tentaz-testimonial-slider';
    }       

    /**
     * Get widget title.
     *
     * Retrieve rsgallery widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Tentaz Testimonial Slider', 'tentaz' );
    }

    /**
     * Get widget icon.
     *
     * Retrieve rsgallery widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'glyph-icon flaticon-slider-2';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the rsgallery widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tentazcore_category' ];
    }

    /**
     * Register rsgallery widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'Content', 'tentaz' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        ); 

        $this->add_control(
            'testimonial_style',
            [
                'label'   => esc_html__( 'Select Testimonial Style', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'style1',
                'options' => [                  
                    'style1' => esc_html__( 'Style 1', 'tentaz'),
                    'style2' => esc_html__( 'Style 2', 'tentaz'),
                    'style3' => esc_html__( 'Style 3', 'tentaz'),
                ],
            ]
        );


        $this->add_control(
            'per_page',
            [
                'label' => esc_html__( 'Testimonial Show Per Page', 'tentaz' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( '5', 'tentaz' ),
                'separator' => 'before',
            ]
        );   
        
        $this->add_control(
            'word_show',
            [
                'label' => esc_html__( 'Word Limit', 'tentaz' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => esc_html__( '30', 'tentaz' ),
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'large',
                'separator' => 'before',
                'exclude' => [
                    'custom'
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'align',
            [
                'label' => esc_html__( 'Alignment', 'tentaz' ),
                'type' => Controls_Manager::CHOOSE,
                'label_block' => false,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'tentaz' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'tentaz' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'tentaz' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                   
                ],
                'toggle' => false,
                'default' => 'left',
                'prefix_class' => 'tentaz-testimonial--',
                'selectors' => [
                    '{{WRAPPER}} .tentaz-testimonial' => 'text-align: {{VALUE}}'
                ]
               
            ]
        );

        $this->add_control(
            'icon_type',
            [
                'label'   => esc_html__( 'Select Icon Type', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'image',            
                'options' => [                  
                    'image' => esc_html__( 'Image', 'tentaz'),                                
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'image_width_qud',
            [
                'label' => esc_html__( 'Width', 'tentaz' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 250,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tentaz-clients-slider .inner-items .tentaz-content .quote-image img' => 'width: {{SIZE}}{{UNIT}};',                    
                ],
                'condition' => [
                    'icon_type' => 'image',
                ]
            ]
        );

        $this->add_control(
            'selected_image',
            [
                'label' => esc_html__( 'Choose Image', 'tentaz' ),
                'type'  => Controls_Manager::MEDIA,             
                
                'condition' => [
                    'icon_type' => 'image',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_slider',
            [
                'label' => esc_html__( 'Slider Settings', 'tentaz' ),
                'tab'   => Controls_Manager::TAB_CONTENT,               
            ]
        );

    
        $this->add_control(
            'col_lg',
            [
                'label'   => esc_html__( 'Desktops > 1199px', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 3,
                'options' => [
                    '1' => esc_html__( '1 Column', 'tentaz' ), 
                    '2' => esc_html__( '2 Column', 'tentaz' ),
                    '3' => esc_html__( '3 Column', 'tentaz' ),
                    '4' => esc_html__( '4 Column', 'tentaz' ),
                    '6' => esc_html__( '6 Column', 'tentaz' ),                 
                ],
                'separator' => 'before',                            
            ]
            
        );

        $this->add_control(
            'col_md',
            [
                'label'   => esc_html__( 'Desktops > 991px', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 3,         
                'options' => [
                    '1' => esc_html__( '1 Column', 'tentaz' ), 
                    '2' => esc_html__( '2 Column', 'tentaz' ),
                    '3' => esc_html__( '3 Column', 'tentaz' ),
                    '4' => esc_html__( '4 Column', 'tentaz' ),
                    '6' => esc_html__( '6 Column', 'tentaz' ),                     
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'col_sm',
            [
                'label'   => esc_html__( 'Tablets > 767px', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 2,         
                'options' => [
                    '1' => esc_html__( '1 Column', 'tentaz' ), 
                    '2' => esc_html__( '2 Column', 'tentaz' ),
                    '3' => esc_html__( '3 Column', 'tentaz' ),
                    '4' => esc_html__( '4 Column', 'tentaz' ),
                    '6' => esc_html__( '6 Column', 'tentaz' ),                 
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'col_xs',
            [
                'label'   => esc_html__( 'Tablets < 768px', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 1,         
                'options' => [
                    '1' => esc_html__( '1 Column', 'tentaz' ), 
                    '2' => esc_html__( '2 Column', 'tentaz' ),
                    '3' => esc_html__( '3 Column', 'tentaz' ),
                    '4' => esc_html__( '4 Column', 'tentaz' ),
                    '6' => esc_html__( '6 Column', 'tentaz' ),                 
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slides_ToScroll',
            [
                'label'   => esc_html__( 'Slide To Scroll', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 2,         
                'options' => [
                    '1' => esc_html__( '1 Item', 'tentaz' ),
                    '2' => esc_html__( '2 Item', 'tentaz' ),
                    '3' => esc_html__( '3 Item', 'tentaz' ),
                    '4' => esc_html__( '4 Item', 'tentaz' ),                   
                ],
                'separator' => 'before',
                            
            ]
            
        );      

        $this->add_control(
            'slider_dots',
            [
                'label'   => esc_html__( 'Navigation Dots', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 'false',
                'options' => [
                    'true' => esc_html__( 'Enable', 'tentaz' ),
                    'false' => esc_html__( 'Disable', 'tentaz' ),              
                ],
                'separator' => 'before',                            
            ]            
        );

        $this->add_control(
            'slider_nav',
            [
                'label'   => esc_html__( 'Navigation Nav', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 'false',           
                'options' => [
                    'true' => esc_html__( 'Enable', 'tentaz' ),
                    'false' => esc_html__( 'Disable', 'tentaz' ),              
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_autoplay',
            [
                'label'   => esc_html__( 'Autoplay', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 'false',           
                'options' => [
                    'true' => esc_html__( 'Enable', 'tentaz' ),
                    'false' => esc_html__( 'Disable', 'tentaz' ),              
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_autoplay_speed',
            [
                'label'   => esc_html__( 'Autoplay Slide Speed', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 3000,          
                'options' => [
                    '1000' => esc_html__( '1 Seconds', 'tentaz' ),
                    '2000' => esc_html__( '2 Seconds', 'tentaz' ), 
                    '3000' => esc_html__( '3 Seconds', 'tentaz' ), 
                    '4000' => esc_html__( '4 Seconds', 'tentaz' ), 
                    '5000' => esc_html__( '5 Seconds', 'tentaz' ), 
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_stop_on_hover',
            [
                'label'   => esc_html__( 'Stop on Hover', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',               
                'options' => [
                    'true' => esc_html__( 'Enable', 'tentaz' ),
                    'false' => esc_html__( 'Disable', 'tentaz' ),              
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_interval',
            [
                'label'   => esc_html__( 'Autoplay Interval', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,  
                'default' => 3000,          
                'options' => [
                    '5000' => esc_html__( '5 Seconds', 'tentaz' ), 
                    '4000' => esc_html__( '4 Seconds', 'tentaz' ), 
                    '3000' => esc_html__( '3 Seconds', 'tentaz' ), 
                    '2000' => esc_html__( '2 Seconds', 'tentaz' ), 
                    '1000' => esc_html__( '1 Seconds', 'tentaz' ),     
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_loop',
            [
                'label'   => esc_html__( 'Loop', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',
                'options' => [
                    'true' => esc_html__( 'Enable', 'tentaz' ),
                    'false' => esc_html__( 'Disable', 'tentaz' ),
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'slider_centerMode',
            [
                'label'   => esc_html__( 'Center Mode', 'tentaz' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',
                'options' => [
                    'true' => esc_html__( 'Enable', 'tentaz' ),
                    'false' => esc_html__( 'Disable', 'tentaz' ),
                ],
                'separator' => 'before',
                            
            ]
            
        );

        $this->add_control(
            'item_gap_custom',
            [
                'label' => esc_html__( 'Item Middle Gap', 'tentaz' ),
                'type' => Controls_Manager::SLIDER,
                'show_label' => true,               
                'range' => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 15,
                ],          

                'selectors' => [
                    '{{WRAPPER}} .tentaz-clients-slider .inner-items' => 'margin-left:{{SIZE}}{{UNIT}};',     
                    '{{WRAPPER}} .tentaz-clients-slider .inner-items' => 'margin-right:{{SIZE}}{{UNIT}};',                    
                ],
            ]
        ); 

         $this->add_control(
            'item_gap_custom_bottom',
            [
                'label' => esc_html__( 'Item Bottom Gap', 'tentaz' ),
                'type' => Controls_Manager::SLIDER,
                'show_label' => true,               
                'range' => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 15,
                ],          

                'selectors' => [
                    '{{WRAPPER}} .tentaz-clients-slider .inner-items' => 'margin-bottom:{{SIZE}}{{UNIT}};',                    
                ],
            ]
        ); 
                
        $this->end_controls_section();

        $this->start_controls_section(
            'section_slider_style',
            [
                'label' => esc_html__( 'Title/Designation/Ratings', 'tentaz' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Title Color', 'tentaz' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tentaz-clients-slider .inner-items .tentaz-bottom .tentaz-author-name em' => 'color: {{VALUE}};',             

                ],                
            ]
        );


        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => esc_html__( 'Title Typography', 'tentaz' ),
                'selector' => '{{WRAPPER}} .tentaz-clients-slider .inner-items .tentaz-bottom .tentaz-author-name em',                     
            ]
        );


        $this->add_control(
            'designation_color',
            [
                'label' => esc_html__( 'Designation Color', 'tentaz' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [                    
                    '{{WRAPPER}} .tentaz-clients-slider .inner-items .tentaz-bottom .tentaz-author-name' => 'color: {{VALUE}};',

                ],                
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'designation_typography',
                'label' => esc_html__( 'Designation Typography', 'tentaz' ),
                'selector' => '{{WRAPPER}} .tentaz-clients-slider .inner-items .tentaz-bottom .tentaz-author-name',                    
            ]
        );  

        $this->end_controls_section();
        
        $this->start_controls_section(
            'section_content_style',
            [
                'label' => esc_html__( 'Testimonial Content', 'tentaz' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_control(
            'content_color',
            [
                'label' => esc_html__( 'Content Color', 'tentaz' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tentaz-clients-slider .inner-items .tentaz-content, {{WRAPPER}} .tentaz-clients-slider .inner-items .tentaz-content p' => 'color: {{VALUE}};',                    

                ],                
            ]
        );

          $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'label' => esc_html__( 'Content Typography', 'tentaz' ),
                'selector' => '{{WRAPPER}} .tentaz-clients-slider .inner-items .tentaz-content, {{WRAPPER}} .tentaz-clients-slider .inner-items .tentaz-content p'
            ]
        );

        $this->end_controls_section();

         $this->start_controls_section(
            'section_quote_style',
            [
                'label' => esc_html__( 'Quote Image', 'tentaz' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'image_width_author',
            [
                'label' => esc_html__( 'Width', 'tentaz' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 250,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tentaz-clients-slider .inner-items .tentaz-bottom .tentaz-author img' => 'width: {{SIZE}}{{UNIT}};',                    
                ],
                'condition' => [
                    'icon_type' => 'image',
                ]
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'section_slider_style_arrow',
            [
                'label' => esc_html__( 'Slider Style', 'tentaz' ),
                'tab' => Controls_Manager::TAB_STYLE,

            ]
        );     
       
      
        $this->add_control(
            'arrow_options',
            [
                'label' => esc_html__( 'Arrow Style', 'tentaz' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'navigation_arrow_background',
            [
                'label' => esc_html__( 'Background', 'tentaz' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tentaz-addon-slider .slick-next, .tentaz-addon-slider .slick-prev' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .tentaz-addon-slider .slick-next, .tentaz-addon-slider .slick-next' => 'background: {{VALUE}};',

                ],                
            ]
        );

        $this->add_control(
            'navigation_arrow_icon_color',
            [
                'label' => esc_html__( 'Icon Color', 'tentaz' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tentaz-addon-slider .slick-next::before' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .tentaz-addon-slider .slick-prev::before' => 'color: {{VALUE}};',

                ],                
            ]
        );

        $this->add_control(
            'bullet_options',
            [
                'label' => esc_html__( 'Bullet Style', 'tentaz' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->add_control(
            'navigation_dot_border_color',
            [
                'label' => esc_html__( 'Background Color (Default)', 'tentaz' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tentaz-unique-slider .slick-dots li button' => 'background-color: {{VALUE}};',
                ],                
            ]
        );

        $this->add_control(
            'navigation_dot_icon_background',
            [
                'label' => esc_html__( 'Background Color (Active)', 'tentaz' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tentaz-unique-slider .slick-dots li.slick-active button' => 'background-color: {{VALUE}};',
                ],                
            ]
        );       
        $this->end_controls_section(); 
    }

    /**
     * Render rsgallery widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */

    protected function render() {
        $settings = $this->get_settings_for_display();

        $slidesToShow    = !empty($settings['col_lg']) ? $settings['col_lg'] : 3;
        $autoplaySpeed   = $settings['slider_autoplay_speed'];
        $interval        = $settings['slider_interval'];
        $slidesToScroll  = $settings['slides_ToScroll'];
        $slider_autoplay = $settings['slider_autoplay'] === 'true' ? 'true' : 'false';
        $pauseOnHover    = $settings['slider_stop_on_hover'] === 'true' ? 'true' : 'false';
        $sliderDots      = $settings['slider_dots'] == 'true' ? 'true' : 'false';
        $sliderNav       = $settings['slider_nav'] == 'true' ? 'true' : 'false';        
        $infinite        = $settings['slider_loop'] === 'true' ? 'true' : 'false';
        $centerMode      = $settings['slider_centerMode'] === 'true' ? 'true' : 'false';
        $col_lg          = $settings['col_lg'];
        $col_md          = $settings['col_md'];
        $col_sm          = $settings['col_sm'];
        $col_xs          = $settings['col_xs'];
        
        $unique = rand(2012,35120);

        $slider_conf = compact('slidesToShow', 'autoplaySpeed', 'interval', 'slidesToScroll', 'slider_autoplay','pauseOnHover', 'sliderDots', 'sliderNav', 'infinite', 'centerMode', 'col_lg', 'col_md', 'col_sm', 'col_xs');   

        ?>  
            <div class="tentaz-unique-slider tentaz-clients-slider">
                <?php if('style1' == $settings['testimonial_style']) { ?>  
                    <div id="tentaz-slick-slider-<?php echo esc_attr($unique); ?>" class="tentaz-addon-slider style__1">
                        <?php
                            $url = plugin_dir_url( __FILE__ );

                            $best_wp = new wp_Query(array(
                                'post_type'      => 'testimonials',
                                'posts_per_page' => $settings['per_page'],                     
                            ));

                            while($best_wp->have_posts()): $best_wp->the_post();
                            $designation  = !empty(get_post_meta( get_the_ID(), 'designation', true )) ? get_post_meta( get_the_ID(), 'designation', true ):'';
                            $ratings  = !empty(get_post_meta( get_the_ID(), 'ratings', true )) ? get_post_meta( get_the_ID(), 'ratings', true ):''; 

                            if(!empty($settings['word_show'])){
                                $limit = $settings['word_show'];
                            }
                            else{
                                $limit = 200;
                            }

                            ?>                           
                              
                            <div class="testimonial-items">
                                <div class="inner-items">                                    
                                    <div class="tentaz-content">
                                        <?php if(!empty($settings['selected_image']['url'])) :?>
                                            <span class="quote-image"><img src="<?php echo esc_url( $settings['selected_image']['url'] );?>" alt="image"/></span>
                                        <?php endif;?>
                                        <?php echo wp_trim_words( get_the_content(), $limit, '' ); ?>
                                        <div class="tentaz-rating"><img src="<?php echo esc_url($url); ?>/img/<?php echo esc_html($ratings); ?>.png" class="tentaz__star" alt="ratings" /></div>
                                    </div>
                                    <div class="tentaz-bottom">
                                        <span class="tentaz-author">
                                            <?php the_post_thumbnail($settings['thumbnail_size']); ?>
                                        </span>
                                        <span class="tentaz-author-name">
                                            <em><?php the_title();?></em> 
                                            <?php echo esc_html( $designation );?>
                                        </span>                                    
                                    </div>
                                </div>
                            </div>
                                
                            <?php   
                            endwhile;
                            wp_reset_query(); 
                        ?>  
                    </div>
                <?php } elseif('style3' == $settings['testimonial_style']) { ?> 
                    <div id="tentaz-slick-slider-<?php echo esc_attr($unique); ?>" class="tentaz-addon-slider style__3">
                        <?php
                            $url = plugin_dir_url( __FILE__ );

                            $best_wp = new wp_Query(array(
                                'post_type'      => 'testimonials',
                                'posts_per_page' => $settings['per_page'],                     
                            ));

                            while($best_wp->have_posts()): $best_wp->the_post();
                            $designation  = !empty(get_post_meta( get_the_ID(), 'designation', true )) ? get_post_meta( get_the_ID(), 'designation', true ):'';
                            $ratings  = !empty(get_post_meta( get_the_ID(), 'ratings', true )) ? get_post_meta( get_the_ID(), 'ratings', true ):''; 

                            if(!empty($settings['word_show'])){
                                $limit = $settings['word_show'];
                            }
                            else{
                                $limit = 200;
                            }

                            ?>                           
                              
                            <div class="testimonial-items">
                                <div class="inner-items">                                    
                                    <div class="tentaz-content">
                                        <?php if(!empty($settings['selected_image']['url'])) :?>
                                            <span class="quote-image"><img src="<?php echo esc_url( $settings['selected_image']['url'] );?>" alt="image"/></span>
                                        <?php endif;?>
                                        <?php echo wp_trim_words( get_the_content(), $limit, '' ); ?>
                                    </div>
                                    <div class="tentaz-bottom">
                                        <span class="tentaz-author">
                                            <?php the_post_thumbnail($settings['thumbnail_size']); ?>
                                        </span>
                                        <span class="tentaz-author-name">
                                            <em><?php the_title();?></em> 
                                            <?php echo esc_html( $designation );?>
                                        </span>                                    
                                    </div>
                                </div>
                            </div>
                                
                            <?php   
                            endwhile;
                            wp_reset_query(); 
                        ?>  
                    </div>
                <?php } else { ?>
                    <div id="tentaz-slick-slider-<?php echo esc_attr($unique); ?>" class="tentaz-addon-slider style__2">
                        <?php
                            $url = plugin_dir_url( __FILE__ );

                            $best_wp = new wp_Query(array(
                                'post_type'      => 'testimonials',
                                'posts_per_page' => $settings['per_page'],                     
                            ));

                            while($best_wp->have_posts()): $best_wp->the_post();
                            $designation  = !empty(get_post_meta( get_the_ID(), 'designation', true )) ? get_post_meta( get_the_ID(), 'designation', true ):'';
                            $ratings  = !empty(get_post_meta( get_the_ID(), 'ratings', true )) ? get_post_meta( get_the_ID(), 'ratings', true ):''; 

                            if(!empty($settings['word_show'])){
                                $limit = $settings['word_show'];
                            }
                            else{
                                $limit = 200;
                            }

                            ?>                           
                              
                            <div class="testimonial-items">
                                <div class="inner-items">
                                    <?php if(!empty($settings['selected_image']['url'])) :?>
                                        <span class="quote-image"><img src="<?php echo esc_url( $settings['selected_image']['url'] );?>" alt="image"/></span>
                                    <?php endif;?>  

                                    <div class="con__section_tn">
                                        <div class="tentaz-bottom">
                                            <span class="tentaz-author">
                                                <?php the_post_thumbnail($settings['thumbnail_size']); ?>
                                            </span>
                                            <span class="tentaz-author-name">
                                                <em><?php the_title();?></em> 
                                                <?php echo esc_html( $designation );?>
                                            </span>                                    
                                        </div>
                                        <div class="tentaz-content">                                        
                                            <?php echo wp_trim_words( get_the_content(), $limit, '' ); ?>
                                            
                                            <img src="<?php echo esc_url($url); ?>/img/<?php echo esc_html($ratings); ?>.png" class="tentaz__star" alt="ratings" />

                                        </div>
                                    </div>                                    
                                </div>
                            </div>
                                
                            <?php   
                            endwhile;
                            wp_reset_query(); 

                         ?>  
                    </div>
                <?php } ?>

                <div class="tentaz-slider-conf wpsisac-hide" data-conf="<?php echo htmlspecialchars(json_encode($slider_conf)); ?>"></div>
            </div>



            <?php if(('style1' == $settings['testimonial_style']) || ('style2' == $settings['testimonial_style']) || ('style3' == $settings['testimonial_style'])):?>  
                <script type="text/javascript"> 
                    jQuery(document).ready(function(){
                        jQuery( '.tentaz-addon-slider' ).each(function( index ) {        
                        var slider_id       = jQuery(this).attr('id'); 
                        var slider_conf     = jQuery.parseJSON( jQuery(this).closest('.tentaz-unique-slider').find('.tentaz-slider-conf').attr('data-conf'));
                       
                        if( typeof(slider_id) != 'undefined' && slider_id != '' ) {
                        jQuery('#'+slider_id).not('.slick-initialized').slick({
                        slidesToShow    : parseInt(slider_conf.col_lg),
                        centerMode      : (slider_conf.centerMode)  == "true" ? true : false,
                        dots            : (slider_conf.sliderDots)  == "true" ? true : false,
                        arrows          : (slider_conf.sliderNav) == "true" ? true : false,
                        autoplay        : (slider_conf.slider_autoplay) == "true" ? true : false,
                        slidesToScroll  : parseInt(slider_conf.slidesToScroll),
                        centerPadding   : '15px',
                        autoplaySpeed   : parseInt(slider_conf.autoplaySpeed),
                        pauseOnHover    : (slider_conf.pauseOnHover) == "true" ? true : false,
                        loop : false,

                        responsive: [{
                            breakpoint: 1200,
                            settings: {
                                slidesToShow: parseInt(slider_conf.col_md),
                            }
                        }, 
                        {
                            breakpoint: 992,
                            settings: {
                                slidesToShow: parseInt(slider_conf.col_sm),
                            }
                        }, 
                        {
                            breakpoint: 768,
                            settings: {
                                arrows: false,
                                slidesToShow: parseInt(slider_conf.col_xs),
                            }
                        }, ]
                        });
                    }
           
                 });
                    });
                </script>
            <?php endif; ?>

        <?php        
        
    }
}?>